CREATE OR REPLACE PROCEDURE SP_SHINSEI_T_0010_016
(USER_ID in varchar)
AS
--���[�N�t���[�u�\���v�������s

BEGIN
    --�Z�[�u�|�C���g����
    SAVEPOINT SAVE1;

    --���[�N�t���[�S���e�[�u����ǉ�/�X�V
    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '1' AS WF_NO
              , SHAIN_CD_1 AS SHAIN_CD
              , SHAIN_MEI_1 AS SHAIN_MEI
              , YAKUSHOKU_MEI_1 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_016
            WHERE W_0010_016.W_USER_ID = USER_ID
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , W1.ROW_NO
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '2' AS WF_NO
              , SHAIN_CD_2 AS SHAIN_CD
              , SHAIN_MEI_2 AS SHAIN_MEI
              , YAKUSHOKU_MEI_2 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_016
            WHERE W_0010_016.W_USER_ID = USER_ID
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , W1.ROW_NO
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '3' AS WF_NO
              , SHAIN_CD_3 AS SHAIN_CD
              , SHAIN_MEI_3 AS SHAIN_MEI
              , YAKUSHOKU_MEI_3 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_016
            WHERE W_0010_016.W_USER_ID = USER_ID
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , W1.ROW_NO
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '4' AS WF_NO
              , SHAIN_CD_4 AS SHAIN_CD
              , SHAIN_MEI_4 AS SHAIN_MEI
              , YAKUSHOKU_MEI_4 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_016
            WHERE W_0010_016.W_USER_ID = USER_ID
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , W1.ROW_NO
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '5' AS WF_NO
              , SHAIN_CD_5 AS SHAIN_CD
              , SHAIN_MEI_5 AS SHAIN_MEI
              , YAKUSHOKU_MEI_5 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_016
            WHERE W_0010_016.W_USER_ID = USER_ID
              AND W_0010_016.KBN <> 1--���i�S���̃��[�N�t���[��WF_NO=5��INSERT���Ȃ�
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , W1.ROW_NO
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );


    --���[�N�t���[�����e�[�u���Ɂu�\���v���R�[�h�ǉ�
        INSERT INTO
               T_0010_022 (
                    TEIKYO_KANRI_NO
                  , VERSION_NO
                  , RIREKI_NO
                  , KBN
                  , ROW_NO
                  , WF_NO
                  , SHAIN_CD
                  , SHAIN_MEI
                  , YAKUSHOKU_MEI
                  , RESULT_CD
                  , RESULT_MEI
                  , PROCESSING_DATE
                  , CMNT
                  , DBS_STATUS
                  , DBS_CREATE_USER
                  , DBS_CREATE_DATE
                  , DBS_UPDATE_USER
                  , DBS_UPDATE_DATE
                        )
               SELECT
                    TEIKYO_KANRI_NO
                  , VERSION_NO
                  , NVL((SELECT MAX(A.RIREKI_NO)+1 FROM T_0010_022 A WHERE A.TEIKYO_KANRI_NO=W_0010_016.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_016.VERSION_NO),1)
                  , KBN
                  , ROW_NO
                  , '1'
                  , SHAIN_CD_1
                  , SHAIN_MEI_1
                  , YAKUSHOKU_MEI_1
                  , '0'
                  , '�\��'
                  , sysdate
                  , CMNT
                  , DBS_STATUS
                  , DBS_CREATE_USER
                  , DBS_CREATE_DATE
                  , DBS_UPDATE_USER
                  , DBS_UPDATE_DATE
                 FROM W_0010_016
                WHERE W_0010_016.W_USER_ID = USER_ID;

    --���ʏ���
    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_016
     WHERE W_0010_016.W_USER_ID = USER_ID;


    --����I��
    --�������ʕԋp


-- ��O����
EXCEPTION
    when others then
    --�g�����U�N�V���������[���o�b�N�i�L�����Z���j
    ROLLBACK TO SAVE1;

    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_016
     WHERE W_0010_016.W_USER_ID = USER_ID;

    --�ُ�I��
    --�������ʕԋp
    RAISE;


END;
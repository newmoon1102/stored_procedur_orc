CREATE OR REPLACE PROCEDURE SP_SAVE_T_0010_005
(
  vUSER_ID in varchar
  ,vTEIKYO_KANRI_NO in varchar--�폜�̂��߂ɁATEIKYO_KANRI_NO�AVERSION_NO���p�����[�^�Ŏ󂯎��
  ,vVERSION_NO in number
)
AS
--���������e�[�u��(T_0010_005)�ۑ�����

BEGIN
    --�Z�[�u�|�C���g����
    SAVEPOINT SAVE1;


    --T_0010_005�ɂ����āAW_0010_005�ɂȂ�ROW_NO���폜
    DELETE
    FROM T_0010_005
    WHERE T_0010_005.TEIKYO_KANRI_NO = vTEIKYO_KANRI_NO
      AND T_0010_005.VERSION_NO = vVERSION_NO
      AND NOT EXISTS
      (
      SELECT *
      FROM W_0010_005
      WHERE T_0010_005.TEIKYO_KANRI_NO = W_0010_005.TEIKYO_KANRI_NO
        AND T_0010_005.VERSION_NO = W_0010_005.VERSION_NO
        AND T_0010_005.TANTO_KBN  = W_0010_005.TANTO_KBN
        AND T_0010_005.FC_KBN     = W_0010_005.FC_KBN
        AND W_0010_005.W_USER_ID  = vUSER_ID
      )
    ;

    --�ǉ�/�X�V
    MERGE INTO
           T_0010_005
    USING (
        SELECT
               TEIKYO_KANRI_NO
              ,VERSION_NO
              ,TANTO_KBN
              ,FC_KBN
              ,BUSHO_CD
              ,BUSHO_MEI
              ,TANTOSHA_CD
              ,TANTOSHA_MEI
              ,TEL_NO
              ,NAISEN_NO
              ,MAIL_ADDRESS
              ,DBS_STATUS
              ,DBS_CREATE_USER
              ,DBS_CREATE_DATE
              ,DBS_UPDATE_USER
              ,DBS_UPDATE_DATE
             FROM W_0010_005
            WHERE W_0010_005.W_USER_ID = vUSER_ID
    ) W1 ON (
            T_0010_005.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_005.VERSION_NO      = W1.VERSION_NO
        AND T_0010_005.TANTO_KBN       = W1.TANTO_KBN
        AND T_0010_005.FC_KBN          = W1.FC_KBN
    )
    WHEN MATCHED THEN
        UPDATE SET
             BUSHO_CD        = W1.BUSHO_CD
            ,BUSHO_MEI       = W1.BUSHO_MEI
            ,TANTOSHA_CD     = W1.TANTOSHA_CD
            ,TANTOSHA_MEI    = W1.TANTOSHA_MEI
            ,TEL_NO          = W1.TEL_NO
            ,NAISEN_NO       = W1.NAISEN_NO
            ,MAIL_ADDRESS    = W1.MAIL_ADDRESS
            ,DBS_STATUS      = W1.DBS_STATUS
            ,DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            ,DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
               ,VERSION_NO
               ,TANTO_KBN
               ,FC_KBN
               ,BUSHO_CD
               ,BUSHO_MEI
               ,TANTOSHA_CD
               ,TANTOSHA_MEI
               ,TEL_NO
               ,NAISEN_NO
               ,MAIL_ADDRESS
               ,DBS_STATUS
               ,DBS_CREATE_USER
               ,DBS_CREATE_DATE
               ,DBS_UPDATE_USER
               ,DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
               ,W1.VERSION_NO
               ,W1.TANTO_KBN
               ,W1.FC_KBN
               ,W1.BUSHO_CD
               ,W1.BUSHO_MEI
               ,W1.TANTOSHA_CD
               ,W1.TANTOSHA_MEI
               ,W1.TEL_NO
               ,W1.NAISEN_NO
               ,W1.MAIL_ADDRESS
               ,W1.DBS_STATUS
               ,W1.DBS_CREATE_USER
               ,W1.DBS_CREATE_DATE
               ,W1.DBS_UPDATE_USER
               ,W1.DBS_UPDATE_DATE
        );

    --���ʏ���
    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_005
     WHERE W_0010_005.W_USER_ID = vUSER_ID;


    --����I��
    --�������ʕԋp


-- ��O����
EXCEPTION
    WHEN OTHERS THEN
    --�g�����U�N�V���������[���o�b�N�i�L�����Z���j
    ROLLBACK TO SAVE1;

    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_005
     WHERE W_0010_005.W_USER_ID = vUSER_ID;

    --�ُ�I��
    --�������ʕԋp
    RAISE;


END;
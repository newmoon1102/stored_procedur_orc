CREATE OR REPLACE PROCEDURE SP_SAVE_T_0010_015
(
   vUSER_ID in varchar
  ,vTEIKYO_KANRI_NO in varchar--�폜�̂��߂ɁATEIKYO_KANRI_NO�AVERSION_NO���p�����[�^�Ŏ󂯎��
  ,vVERSION_NO in number
)
AS
--���[�N�t���[�u�\���v�������s
	vMAX_ROW_NO int;
	vMAX_ROW_NO_021 int;
	vMAX_ROW_NO_022 int;


BEGIN
    --�Z�[�u�|�C���g����
    SAVEPOINT SAVE1;

	--���[�N�t���[�S���e�[�u��(T_0010_021)�܂��̓��[�N�t���[�����e�[�u��(T_0010_022)�Ŏg�p����Ă���ő��ROW_NO�𒊏o����B
	--�s�ǉ����ꂽ�s�͂���ROW_NO+1����n�߂�

	SELECT NVL(MAX(ROW_NO),0) INTO vMAX_ROW_NO_021
	FROM T_0010_021
	WHERE TEIKYO_KANRI_NO = vTEIKYO_KANRI_NO
	  AND VERSION_NO = vVERSION_NO
	  AND KBN = 1;

	SELECT NVL(MAX(ROW_NO),0) INTO vMAX_ROW_NO_022
	FROM T_0010_022
	WHERE TEIKYO_KANRI_NO = vTEIKYO_KANRI_NO
	  AND VERSION_NO = vVERSION_NO
	  AND KBN = 1;

	IF vMAX_ROW_NO_021 > vMAX_ROW_NO_022 THEN
		vMAX_ROW_NO := vMAX_ROW_NO_021;
	ELSE
		vMAX_ROW_NO := vMAX_ROW_NO_022;
	END IF;

    --1. �s�폜���ꂽ���[�N�t���[���폜
	--�@���[�N�t���[���i�e�[�u��(T_0010_020)�ɂ����āA���[�N�e�[�u��(W_0010_015)�ɂȂ�ROW_NO���폜
		DELETE
		FROM T_0010_020
		WHERE TEIKYO_KANRI_NO = vTEIKYO_KANRI_NO
		AND VERSION_NO = vVERSION_NO
		AND NOT EXISTS
		(
			SELECT *
			FROM W_0010_015
			WHERE W_0010_015.TEIKYO_KANRI_NO = T_0010_020.TEIKYO_KANRI_NO
			  AND W_0010_015.VERSION_NO = T_0010_020.VERSION_NO
			  AND W_0010_015.KBN = T_0010_020.KBN
			  AND W_0010_015.ROW_NO = T_0010_020.ROW_NO
			  AND W_0010_015.W_USER_ID = vUSER_ID
		);

	--�@���[�N�t���[�S���e�[�u��(T_0010_021)�ɂ����āA���[�N�e�[�u��(W_0010_015)�ɂȂ�ROW_NO���폜
		DELETE
		FROM T_0010_021
		WHERE TEIKYO_KANRI_NO = vTEIKYO_KANRI_NO
		AND VERSION_NO = vVERSION_NO
		AND NOT EXISTS
		(
			SELECT *
			FROM W_0010_015
			WHERE W_0010_015.TEIKYO_KANRI_NO = T_0010_021.TEIKYO_KANRI_NO
			  AND W_0010_015.VERSION_NO = T_0010_021.VERSION_NO
			  AND W_0010_015.KBN = T_0010_021.KBN
			  AND W_0010_015.ROW_NO = T_0010_021.ROW_NO
			  AND W_0010_015.W_USER_ID = vUSER_ID
		);


	--2. �s�ǉ��A�܂��͍X�V���ꂽ���[�N�t���[��ǉ�/�X�V
    --�@���[�N�t���[���i�e�[�u��(T_0010_020)
    MERGE INTO
           T_0010_020
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
			  , SORT_NO
			  , BUHIN_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_015
            WHERE W_0010_015.W_USER_ID = vUSER_ID
    ) W1 ON (
            T_0010_020.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_020.VERSION_NO = W1.VERSION_NO
        AND T_0010_020.KBN = W1.KBN
        AND T_0010_020.ROW_NO = W1.ROW_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              BUHIN_MEI = W1.BUHIN_MEI
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
			  , SORT_NO
              , BUHIN_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , CASE WHEN W1.ROW_NO > 0 THEN W1.ROW_NO ELSE vMAX_ROW_NO + (-W1.ROW_NO) END --����ROW_NO�� �V�����s
			  , W1.SORT_NO
			  , W1.BUHIN_MEI
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    --�@���[�N�t���[�S���e�[�u��(T_0010_021)
    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '1' AS WF_NO
              , SHAIN_CD_1 AS SHAIN_CD
              , SHAIN_MEI_1 AS SHAIN_MEI
              , YAKUSHOKU_MEI_1 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_015
            WHERE W_0010_015.W_USER_ID = vUSER_ID
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END --�S���҂��ύX���ꂽ�Ƃ��������t���X�V����
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , CASE WHEN W1.ROW_NO > 0 THEN W1.ROW_NO ELSE vMAX_ROW_NO + (-W1.ROW_NO) END
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '2' AS WF_NO
              , SHAIN_CD_2 AS SHAIN_CD
              , SHAIN_MEI_2 AS SHAIN_MEI
              , YAKUSHOKU_MEI_2 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_015
            WHERE W_0010_015.W_USER_ID = vUSER_ID
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , CASE WHEN W1.ROW_NO > 0 THEN W1.ROW_NO ELSE vMAX_ROW_NO + (-W1.ROW_NO) END
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '3' AS WF_NO
              , SHAIN_CD_3 AS SHAIN_CD
              , SHAIN_MEI_3 AS SHAIN_MEI
              , YAKUSHOKU_MEI_3 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_015
            WHERE W_0010_015.W_USER_ID = vUSER_ID
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , CASE WHEN W1.ROW_NO > 0 THEN W1.ROW_NO ELSE vMAX_ROW_NO + (-W1.ROW_NO) END
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '4' AS WF_NO
              , SHAIN_CD_4 AS SHAIN_CD
              , SHAIN_MEI_4 AS SHAIN_MEI
              , YAKUSHOKU_MEI_4 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_015
            WHERE W_0010_015.W_USER_ID = vUSER_ID
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , CASE WHEN W1.ROW_NO > 0 THEN W1.ROW_NO ELSE vMAX_ROW_NO + (-W1.ROW_NO) END
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    MERGE INTO
           T_0010_021
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , '5' AS WF_NO
              , SHAIN_CD_5 AS SHAIN_CD
              , SHAIN_MEI_5 AS SHAIN_MEI
              , YAKUSHOKU_MEI_5 AS YAKUSHOKU_MEI
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_015
            WHERE W_0010_015.W_USER_ID = vUSER_ID
              AND W_0010_015.KBN <> 1--���i�S���̃��[�N�t���[��WF_NO=5��INSERT���Ȃ�
    ) W1 ON (
            T_0010_021.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_021.VERSION_NO = W1.VERSION_NO
        AND T_0010_021.KBN = W1.KBN
        AND T_0010_021.ROW_NO = W1.ROW_NO
        AND T_0010_021.WF_NO = W1.WF_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
              SHAIN_CD = W1.SHAIN_CD
            , SHAIN_MEI = W1.SHAIN_MEI
            , YAKUSHOKU_MEI = W1.YAKUSHOKU_MEI
			, PROCESSING_DATE = CASE WHEN SHAIN_CD <> W1.SHAIN_CD THEN sysdate ELSE PROCESSING_DATE END
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_CREATE_USER = W1.DBS_CREATE_USER
            , DBS_CREATE_DATE = W1.DBS_CREATE_DATE
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , KBN
              , ROW_NO
              , WF_NO
              , SHAIN_CD
              , SHAIN_MEI
              , YAKUSHOKU_MEI
			  , PROCESSING_DATE
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.KBN
              , CASE WHEN W1.ROW_NO > 0 THEN W1.ROW_NO ELSE vMAX_ROW_NO + (-W1.ROW_NO) END
              , W1.WF_NO
              , W1.SHAIN_CD
              , W1.SHAIN_MEI
              , W1.YAKUSHOKU_MEI
			  , sysdate
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    --���ʏ���
    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_015
     WHERE W_0010_015.W_USER_ID = vUSER_ID;


    --����I��
    --�������ʕԋp


-- ��O����
EXCEPTION
    when others then
    --�g�����U�N�V���������[���o�b�N�i�L�����Z���j
    ROLLBACK TO SAVE1;

    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_015
     WHERE W_0010_015.W_USER_ID = vUSER_ID;

    --�ُ�I��
    --�������ʕԋp
    RAISE;


END;
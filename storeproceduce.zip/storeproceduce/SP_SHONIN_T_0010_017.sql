CREATE OR REPLACE PROCEDURE SP_SHONIN_T_0010_017
(USER_ID in varchar, SYORI_MODE in number)
AS
--���[�N�t���[�u���F�v�������s
--SYORI_MODE; 1(���F(�m�F))�A9(���߂�)�A99(���~)

BEGIN
    --�Z�[�u�|�C���g����
    SAVEPOINT SAVE1;

    IF SYORI_MODE = 1    THEN--1(���F(�m�F))
        INSERT INTO
               T_0010_022 (

                    TEIKYO_KANRI_NO
                  , VERSION_NO
                  , RIREKI_NO
                  , KBN
                  , ROW_NO
                  , WF_NO
                  , SHAIN_CD
                  , SHAIN_MEI
                  , YAKUSHOKU_MEI
                  , RESULT_CD
                  , RESULT_MEI
                  , PROCESSING_DATE
                  , CMNT
                  , DBS_STATUS
                  , DBS_CREATE_USER
                  , DBS_CREATE_DATE
                  , DBS_UPDATE_USER
                  , DBS_UPDATE_DATE
                        )
               SELECT
                    TEIKYO_KANRI_NO
                  , VERSION_NO
                  , NVL((SELECT MAX(A.RIREKI_NO)+1 FROM T_0010_022 A WHERE A.TEIKYO_KANRI_NO=W_0010_017.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_017.VERSION_NO),1)
                  , KBN
                  , ROW_NO
                  , WF_NO
                  , (SELECT SHAIN_CD FROM T_0010_021 A WHERE A.TEIKYO_KANRI_NO=W_0010_017.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_017.VERSION_NO
                      AND A.KBN=W_0010_017.KBN AND A.ROW_NO=W_0010_017.ROW_NO AND A.WF_NO=W_0010_017.WF_NO)
                  , (SELECT SHAIN_MEI FROM T_0010_021 A WHERE A.TEIKYO_KANRI_NO=W_0010_017.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_017.VERSION_NO
                      AND A.KBN=W_0010_017.KBN AND A.ROW_NO=W_0010_017.ROW_NO AND A.WF_NO=W_0010_017.WF_NO)
                  , (SELECT YAKUSHOKU_MEI FROM T_0010_021 A WHERE A.TEIKYO_KANRI_NO=W_0010_017.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_017.VERSION_NO
                      AND A.KBN=W_0010_017.KBN AND A.ROW_NO=W_0010_017.ROW_NO AND A.WF_NO=W_0010_017.WF_NO)
                  , CASE WHEN WF_NO = 5 THEN '2' ELSE '1' END
                  , CASE WHEN WF_NO = 5 THEN '���F' ELSE '�m�F' END
                  , sysdate
                  , CMNT
                  , DBS_STATUS
                  , DBS_CREATE_USER
                  , DBS_CREATE_DATE
                  , DBS_UPDATE_USER
                  , DBS_UPDATE_DATE
                 FROM W_0010_017
                WHERE W_0010_017.W_USER_ID = USER_ID;

	ELSIF SYORI_MODE = 9    THEN--9(���߂�)
        INSERT INTO
               T_0010_022 (

                    TEIKYO_KANRI_NO
                  , VERSION_NO
                  , RIREKI_NO
                  , KBN
                  , ROW_NO
                  , WF_NO
                  , SHAIN_CD
                  , SHAIN_MEI
                  , YAKUSHOKU_MEI
                  , RESULT_CD
                  , RESULT_MEI
                  , PROCESSING_DATE
                  , CMNT
                  , DBS_STATUS
                  , DBS_CREATE_USER
                  , DBS_CREATE_DATE
                  , DBS_UPDATE_USER
                  , DBS_UPDATE_DATE
                        )
               SELECT
                    TEIKYO_KANRI_NO
                  , VERSION_NO
                  , NVL((SELECT MAX(A.RIREKI_NO)+1 FROM T_0010_022 A WHERE A.TEIKYO_KANRI_NO=W_0010_017.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_017.VERSION_NO),1)
                  , KBN
                  , ROW_NO
                  , WF_NO
                  , (SELECT SHAIN_CD FROM T_0010_021 A WHERE A.TEIKYO_KANRI_NO=W_0010_017.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_017.VERSION_NO
                      AND A.KBN=W_0010_017.KBN AND A.ROW_NO=W_0010_017.ROW_NO AND A.WF_NO=W_0010_017.WF_NO)
                  , (SELECT SHAIN_MEI FROM T_0010_021 A WHERE A.TEIKYO_KANRI_NO=W_0010_017.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_017.VERSION_NO
                      AND A.KBN=W_0010_017.KBN AND A.ROW_NO=W_0010_017.ROW_NO AND A.WF_NO=W_0010_017.WF_NO)
                  , (SELECT YAKUSHOKU_MEI FROM T_0010_021 A WHERE A.TEIKYO_KANRI_NO=W_0010_017.TEIKYO_KANRI_NO AND A.VERSION_NO=W_0010_017.VERSION_NO
                      AND A.KBN=W_0010_017.KBN AND A.ROW_NO=W_0010_017.ROW_NO AND A.WF_NO=W_0010_017.WF_NO)
                  , '9'
                  , '���߂�'
                  , sysdate
                  , CMNT
                  , DBS_STATUS
                  , DBS_CREATE_USER
                  , DBS_CREATE_DATE
                  , DBS_UPDATE_USER
                  , DBS_UPDATE_DATE
                 FROM W_0010_017
                WHERE W_0010_017.W_USER_ID = USER_ID;
	END IF;

    --���ʏ���
    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_017
     WHERE W_0010_017.W_USER_ID = USER_ID;


    --����I��
    --�������ʕԋp


-- ��O����
EXCEPTION
    when others then
    --�g�����U�N�V���������[���o�b�N�i�L�����Z���j
    ROLLBACK TO SAVE1;

    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_017
     WHERE W_0010_017.W_USER_ID = USER_ID;

    --�ُ�I��
    --�������ʕԋp
    RAISE;


END;
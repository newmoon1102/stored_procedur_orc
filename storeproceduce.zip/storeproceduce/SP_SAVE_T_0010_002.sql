CREATE OR REPLACE PROCEDURE SP_SAVE_T_0010_002
(
   vUSER_ID in varchar
  ,vTEIKYO_KANRI_NO in varchar--�폜�̂��߂ɁATEIKYO_KANRI_NO�AVERSION_NO���p�����[�^�Ŏ󂯎��
  ,vVERSION_NO in number
)
AS
--���������e�[�u��(T_0010_002)�ۑ�����

BEGIN
    --�Z�[�u�|�C���g����
    SAVEPOINT SAVE1;


	--T_0010_002�ɂ����āAW_0010_002�ɂȂ�ROW_NO���폜
	DELETE
	FROM T_0010_002
	WHERE T_0010_002.TEIKYO_KANRI_NO = vTEIKYO_KANRI_NO
	  AND T_0010_002.VERSION_NO = vVERSION_NO
	  AND NOT EXISTS
	  (
	  SELECT *
	  FROM W_0010_002
	  WHERE T_0010_002.TEIKYO_KANRI_NO = W_0010_002.TEIKYO_KANRI_NO
	    AND T_0010_002.VERSION_NO = W_0010_002.VERSION_NO
	    AND T_0010_002.ROW_NO = W_0010_002.ROW_NO
		AND W_0010_002.W_USER_ID = vUSER_ID
	  )
	;

    --�ǉ�/�X�V
    MERGE INTO
           T_0010_002
    USING (
        SELECT
                TEIKYO_KANRI_NO
              , VERSION_NO
              , ROW_NO
			  , TAISHO
			  , MIKETSUJIKO
			  , TANTO_BUSHO_CD
			  , TANTO_BUSHO_MEI
			  , SAIGOI_YMD
			  , ZANTEI_TORIKIME
			  , TARGET_GAMEN
			  , FIN_FLG
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
             FROM W_0010_002
            WHERE W_0010_002.W_USER_ID = vUSER_ID
    ) W1 ON (
            T_0010_002.TEIKYO_KANRI_NO = W1.TEIKYO_KANRI_NO
        AND T_0010_002.VERSION_NO = W1.VERSION_NO
        AND T_0010_002.ROW_NO = W1.ROW_NO
    )
    WHEN MATCHED THEN
        UPDATE SET
			  TAISHO = W1.TAISHO
			, MIKETSUJIKO = W1.MIKETSUJIKO
			, TANTO_BUSHO_CD = W1.TANTO_BUSHO_CD
			, TANTO_BUSHO_MEI = W1.TANTO_BUSHO_MEI
			, SAIGOI_YMD = W1.SAIGOI_YMD
			, ZANTEI_TORIKIME = W1.ZANTEI_TORIKIME
			, TARGET_GAMEN = W1.TARGET_GAMEN
			, FIN_FLG = W1.FIN_FLG
            , DBS_STATUS = W1.DBS_STATUS
            , DBS_UPDATE_USER = W1.DBS_UPDATE_USER
            , DBS_UPDATE_DATE = W1.DBS_UPDATE_DATE

    WHEN NOT MATCHED THEN
        INSERT (
                TEIKYO_KANRI_NO
              , VERSION_NO
              , ROW_NO
			  , TAISHO
			  , MIKETSUJIKO
			  , TANTO_BUSHO_CD
			  , TANTO_BUSHO_MEI
			  , SAIGOI_YMD
			  , ZANTEI_TORIKIME
			  , TARGET_GAMEN
			  , FIN_FLG
              , DBS_STATUS
              , DBS_CREATE_USER
              , DBS_CREATE_DATE
              , DBS_UPDATE_USER
              , DBS_UPDATE_DATE
        ) VALUES (
                W1.TEIKYO_KANRI_NO
              , W1.VERSION_NO
              , W1.ROW_NO
			  , W1.TAISHO
			  , W1.MIKETSUJIKO
			  , W1.TANTO_BUSHO_CD
			  , W1.TANTO_BUSHO_MEI
			  , W1.SAIGOI_YMD
			  , W1.ZANTEI_TORIKIME
			  , W1.TARGET_GAMEN
			  , W1.FIN_FLG
              , W1.DBS_STATUS
              , W1.DBS_CREATE_USER
              , W1.DBS_CREATE_DATE
              , W1.DBS_UPDATE_USER
              , W1.DBS_UPDATE_DATE
        );

    --���ʏ���
    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_002
     WHERE W_0010_002.W_USER_ID = vUSER_ID;


    --����I��
    --�������ʕԋp


-- ��O����
EXCEPTION
    WHEN OTHERS THEN
    --�g�����U�N�V���������[���o�b�N�i�L�����Z���j
    ROLLBACK TO SAVE1;

    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_002
     WHERE W_0010_002.W_USER_ID = vUSER_ID;

    --�ُ�I��
    --�������ʕԋp
    RAISE;


END;
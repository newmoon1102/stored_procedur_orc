CREATE OR REPLACE PROCEDURE SP_SAVE_T_0010_001
(USER_ID in varchar,SYORI_MODE in number)
AS
--�ۑ��������s

BEGIN
    --�Z�[�u�|�C���g����
    SAVEPOINT SAVE1;

    --�ۑ�����

    IF SYORI_MODE = 2    THEN
        --�f�[�^�X�V
        UPDATE
            (
            SELECT T_0010_001.VERSION_MEI   T_0010_001_VERSION_MEI
            ,T_0010_001.CREATE_YMD          T_0010_001_CREATE_YMD
            ,T_0010_001.TEIKYO_BUSHO_CD     T_0010_001_TEIKYO_BUSHO_CD
            ,T_0010_001.TEIKYO_BUSHO_MEI    T_0010_001_TEIKYO_BUSHO_MEI
            ,T_0010_001.IRAI_KANRI_NO       T_0010_001_IRAI_KANRI_NO
            ,T_0010_001.IRAI_BUSHO_CD       T_0010_001_IRAI_BUSHO_CD
            ,T_0010_001.IRAI_BUSHO_MEI      T_0010_001_IRAI_BUSHO_MEI
            ,T_0010_001.BIKO01              T_0010_001_BIKO01
            ,T_0010_001.BIKO02              T_0010_001_BIKO02
            ,T_0010_001.BIKO03              T_0010_001_BIKO03
            ,T_0010_001.BIKO04              T_0010_001_BIKO04
            ,T_0010_001.BIKO05              T_0010_001_BIKO05
            ,T_0010_001.BIKO06              T_0010_001_BIKO06
            ,T_0010_001.BIKO07              T_0010_001_BIKO07
            ,T_0010_001.BIKO08              T_0010_001_BIKO08
            ,T_0010_001.BIKO09              T_0010_001_BIKO09
            ,T_0010_001.BIKO10              T_0010_001_BIKO10
            ,T_0010_001.BIKO11              T_0010_001_BIKO11
            ,T_0010_001.DBS_UPDATE_USER     T_0010_001_DBS_UPDATE_USER
            ,T_0010_001.DBS_UPDATE_DATE     T_0010_001_DBS_UPDATE_DATE
            ,W_0010_001.VERSION_MEI         W_0010_001_VERSION_MEI
            ,W_0010_001.CREATE_YMD          W_0010_001_CREATE_YMD
            ,W_0010_001.TEIKYO_BUSHO_CD     W_0010_001_TEIKYO_BUSHO_CD
            ,W_0010_001.TEIKYO_BUSHO_MEI    W_0010_001_TEIKYO_BUSHO_MEI
            ,W_0010_001.IRAI_KANRI_NO       W_0010_001_IRAI_KANRI_NO
            ,W_0010_001.IRAI_BUSHO_CD       W_0010_001_IRAI_BUSHO_CD
            ,W_0010_001.IRAI_BUSHO_MEI      W_0010_001_IRAI_BUSHO_MEI
            ,W_0010_001.BIKO01              W_0010_001_BIKO01
            ,W_0010_001.BIKO02              W_0010_001_BIKO02
            ,W_0010_001.BIKO03              W_0010_001_BIKO03
            ,W_0010_001.BIKO04              W_0010_001_BIKO04
            ,W_0010_001.BIKO05              W_0010_001_BIKO05
            ,W_0010_001.BIKO06              W_0010_001_BIKO06
            ,W_0010_001.BIKO07              W_0010_001_BIKO07
            ,W_0010_001.BIKO08              W_0010_001_BIKO08
            ,W_0010_001.BIKO09              W_0010_001_BIKO09
            ,W_0010_001.BIKO10              W_0010_001_BIKO10
            ,W_0010_001.BIKO11              W_0010_001_BIKO11
            ,W_0010_001.DBS_UPDATE_USER     W_0010_001_DBS_UPDATE_USER
            ,W_0010_001.DBS_UPDATE_DATE     W_0010_001_DBS_UPDATE_DATE
          FROM T_0010_001
         INNER JOIN
             W_0010_001
            ON W_0010_001.TEIKYO_KANRI_NO = T_0010_001.TEIKYO_KANRI_NO
           AND W_0010_001.VERSION_NO      = T_0010_001.VERSION_NO
			   WHERE W_USER_ID = USER_ID
                 AND W_ROW     = 1
			)
           SET T_0010_001_VERSION_MEI    = W_0010_001_VERSION_MEI
            ,T_0010_001_CREATE_YMD       = W_0010_001_CREATE_YMD
            ,T_0010_001_TEIKYO_BUSHO_CD  = W_0010_001_TEIKYO_BUSHO_CD
            ,T_0010_001_TEIKYO_BUSHO_MEI = W_0010_001_TEIKYO_BUSHO_MEI
            ,T_0010_001_IRAI_KANRI_NO    = W_0010_001_IRAI_KANRI_NO
            ,T_0010_001_IRAI_BUSHO_CD    = W_0010_001_IRAI_BUSHO_CD
            ,T_0010_001_IRAI_BUSHO_MEI   = W_0010_001_IRAI_BUSHO_MEI
            ,T_0010_001_BIKO01           = W_0010_001_BIKO01
            ,T_0010_001_BIKO02           = W_0010_001_BIKO02
            ,T_0010_001_BIKO03           = W_0010_001_BIKO03
            ,T_0010_001_BIKO04           = W_0010_001_BIKO04
            ,T_0010_001_BIKO05           = W_0010_001_BIKO05
            ,T_0010_001_BIKO06           = W_0010_001_BIKO06
            ,T_0010_001_BIKO07           = W_0010_001_BIKO07
            ,T_0010_001_BIKO08           = W_0010_001_BIKO08
            ,T_0010_001_BIKO09           = W_0010_001_BIKO09
            ,T_0010_001_BIKO10           = W_0010_001_BIKO10
            ,T_0010_001_BIKO11           = W_0010_001_BIKO11
            ,T_0010_001_DBS_UPDATE_USER  = W_0010_001_DBS_UPDATE_USER
            ,T_0010_001_DBS_UPDATE_DATE  = W_0010_001_DBS_UPDATE_DATE;

    --�폜����
--    ELSE IF @MODE = 2

      --�݌Ƀe�[�u���폜
--      DELETE
--        FROM T_0010_001
--       WHERE T_0010_001.ZAIKO_NO = @REF_NO

--    END

    --���̑�����
    ELSE


      --���[�N�e�[�u���N���A
      DELETE
        FROM W_0010_001
       WHERE W_0010_001.W_USER_ID = USER_ID;

    END IF;

    --���ʏ���
    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_001
     WHERE W_0010_001.W_USER_ID = USER_ID;


    --����I��
    --�������ʕԋp


-- ��O����
EXCEPTION
    when others then
    --�g�����U�N�V���������[���o�b�N�i�L�����Z���j
    ROLLBACK TO SAVE1;

    --���[�N�e�[�u���N���A
    DELETE
    FROM W_0010_001
     WHERE W_0010_001.W_USER_ID = USER_ID;

    --�ُ�I��
    --�������ʕԋp
    RAISE;


END;